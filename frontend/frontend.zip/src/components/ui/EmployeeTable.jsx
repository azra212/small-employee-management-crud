import React from "react";

import { MdDelete } from "react-icons/md";

import { For, HStack, Stack, Table } from "@chakra-ui/react";
import { FaRegEdit } from "react-icons/fa";

const EmployeeTable = () => {
  return (
    <Stack gap="10">
      <Table.Root size="md" variant="outline">
        <Table.Header>
          <Table.Row>
            <Table.ColumnHeader>ID</Table.ColumnHeader>
            <Table.ColumnHeader>Name</Table.ColumnHeader>
            <Table.ColumnHeader>Email</Table.ColumnHeader>
            <Table.ColumnHeader>Age</Table.ColumnHeader>
            <Table.ColumnHeader>Role</Table.ColumnHeader>
            <Table.ColumnHeader>Salary</Table.ColumnHeader>
            <Table.ColumnHeader>Actions</Table.ColumnHeader>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {items.map((item) => (
            <Table.Row key={item.id}>
              <Table.Cell>{item.id}</Table.Cell>
              <Table.Cell>{item.name}</Table.Cell>
              <Table.Cell>{item.email}</Table.Cell>
              <Table.Cell>{item.age}</Table.Cell>
              <Table.Cell>{item.role}</Table.Cell>
              <Table.Cell>{item.salary}</Table.Cell>
              <Table.Cell>
                <HStack gap="3">
                  <MdDelete size={20} className="icon" />
                  <FaRegEdit size={20} className="icon" />
                </HStack>
              </Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table.Root>
    </Stack>
  );
};

const items = [
  {
    id: 1,
    name: "Amina Patel",
    email: "amina.patel@example.com",
    age: 34,
    salary: 72000.0,
    role: "Manager",
  },
  {
    id: 2,
    name: "Leo Nguyen",
    email: "leo.nguyen@example.com",
    age: 28,
    salary: 64500.5,
    role: "Developer",
  },
  {
    id: 3,
    name: "Mira Johnson",
    email: "mira.johnson@example.com",
    age: 26,
    salary: 52000.0,
    role: "Intern",
  },
  {
    id: 4,
    name: "David Owens",
    email: "david.owens@example.com",
    age: 41,
    salary: 78000.25,
    role: "Sales",
  },
  {
    id: 5,
    name: "Sara Alavi",
    email: "sara.alavi@example.com",
    age: 30,
    salary: 68000.0,
    role: "HR",
  },
  {
    id: 6,
    name: "Cameron Reed",
    email: "cameron.reed@example.com",
    age: 24,
    salary: 47000.0,
    role: "Developer",
  },
  {
    id: 7,
    name: "Nina Brooks",
    email: "nina.brooks@example.com",
    age: 38,
    salary: 73000.0,
    role: "Manager",
  },
  {
    id: 8,
    name: "Jusuf Mbaye",
    email: "jusuf.mbaye@example.com",
    age: 29,
    salary: 56000.75,
    role: "Sales",
  },
  {
    id: 9,
    name: "Priya Singh",
    email: "priya.singh@example.com",
    age: 33,
    salary: 61000.0,
    role: "HR",
  },
  {
    id: 10,
    name: "Marcus Holt",
    email: "marcus.holt@example.com",
    age: 27,
    salary: 49000.0,
    role: "Intern",
  },
];
export default EmployeeTable;
